package dao;

import model.Combos;
import model.Matricula;

import javax.persistence.EntityManager;
import java.util.List;

public class MatriculaDao {
    private EntityManager em;

    public MatriculaDao (EntityManager em) {
        this.em = em;
    }

    public void cadastrar(Matricula matricula) {
        this.em.persist(matricula);
    }

    public List<Matricula> consulMatricula() {
        String jpql = "SELECT c FROM Matricula c";
        return em.createQuery(jpql, Matricula.class).getResultList();
    }

    public Combos bucarPorId(int idMatricula) {
        return em.find(Combos.class, idMatricula);
    }

    public void remover (Matricula matricula) {
        // carrega no gerenciamento do JPA
        em.merge(matricula);
        //remove produto
        this.em.remove(matricula);
    }

    public void alterar (Matricula matricula) {
        em.merge(matricula);
    }

}
