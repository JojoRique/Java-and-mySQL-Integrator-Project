package dao;

import model.TipoUsu;
import model.Usuario;

import javax.persistence.EntityManager;
import java.util.List;

public class UsuarioDao {
    private EntityManager em;

    public UsuarioDao (EntityManager em) {
        this.em = em;
    }

    public void cadastrar(Usuario usuario) {
        this.em.persist(usuario);
    }

    public List<Usuario> consultaUsu() {
        String jpql = "SELECT c FROM Usuario c";
        return em.createQuery(jpql, Usuario.class).getResultList();
    }

    public TipoUsu bucarPorId(int idUsuario) {
        return em.find(TipoUsu.class, idUsuario);
    }

    public void remover (Usuario usuario) {
        // carrega no gerenciamento do JPA
        em.merge(usuario);
        //remove produto
        this.em.remove(usuario);
    }

    public void alterar (Usuario usuario) {
        em.merge(usuario);
    }

}
