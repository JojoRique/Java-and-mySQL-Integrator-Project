package dao;

import model.TipoUsu;

import javax.persistence.EntityManager;
import java.util.List;

public class TipoUsuDao {
    private EntityManager em;

    public TipoUsuDao(EntityManager em) {
        this.em = em;
    }

    public void cadastrar(TipoUsu tipousu) {
        this.em.persist(tipousu);
    }

    public List<TipoUsu> consultaTodos() {
        String jpql = "SELECT c FROM TipoUsu c";
        return em.createQuery(jpql, TipoUsu.class).getResultList();
    }

    public TipoUsu bucarPorId(int idTipousu) {
        return em.find(TipoUsu.class, idTipousu);
    }

    public void remover (TipoUsu tipousu) {
        // carrega no gerenciamento do JPA
        em.merge(tipousu);
        //remove produto
        this.em.remove(tipousu);
    }

    public void alterar (TipoUsu tipousu) {
        em.merge(tipousu);
    }

}
