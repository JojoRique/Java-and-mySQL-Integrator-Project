package dao;

import model.Combos;
import model.FormaPagamento;

import javax.persistence.EntityManager;
import java.util.List;

public class FormaPagamentoDao {
    private EntityManager em;

    public FormaPagamentoDao(EntityManager em) {
        this.em = em;
    }

    public void cadastrar(FormaPagamento formaPagamento) {
        this.em.persist(formaPagamento);
    }

    public List<FormaPagamento> consultaFormaPgto() {
        String jpql = "SELECT c FROM FormaPagamento c";
        return em.createQuery(jpql, FormaPagamento.class).getResultList();
    }

    public Combos bucarPorId(int idFormapaganto) {
        return em.find(Combos.class, idFormapaganto);
    }

    public void remover (FormaPagamento formaPagamento) {
        // carrega no gerenciamento do JPA
        em.merge(formaPagamento);
        //remove produto
        this.em.remove(formaPagamento);
    }

    public void alterar (Combos combos) {
        em.merge(combos);
    }

}
