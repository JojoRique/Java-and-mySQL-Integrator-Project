package dao;

import model.Agenda;

import javax.persistence.EntityManager;
import java.util.List;

public class AgendaDao {
    private EntityManager em;

    public AgendaDao(EntityManager em) {
        this.em = em;
    }

    public void cadastrar(Agenda agenda) {
        this.em.persist(agenda);
    }

    public List<Agenda> consulAgenda() {
        String jpql = "SELECT c FROM Agenda c";
        return em.createQuery(jpql, Agenda.class).getResultList();
    }

    public Agenda bucarPorId(int idAgenda) {
        return em.find(Agenda.class, idAgenda);
    }

    public void remover (Agenda agenda) {
        // carrega no gerenciamento do JPA
        em.merge(agenda);
        //remove produto
        this.em.remove(agenda);
    }

    public void alterar (Agenda agenda) {
        em.merge(agenda);
    }

}
