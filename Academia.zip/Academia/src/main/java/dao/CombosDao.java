package dao;

import model.Combos;
import model.TipoUsu;

import javax.persistence.EntityManager;
import java.util.List;

public class CombosDao {
    private EntityManager em;

    public CombosDao(EntityManager em) {
        this.em = em;
    }

    public void cadastrar(Combos combos) {
        this.em.persist(combos);
    }

    public List<Combos> consultaCombo() {
        String jpql = "SELECT c FROM Combos c";
        return em.createQuery(jpql, Combos.class).getResultList();
    }

    public Combos bucarPorId(int idCombos) {
        return em.find(Combos.class, idCombos);
    }

    public void remover (Combos combos) {
        // carrega no gerenciamento do JPA
        em.merge(combos);
        //remove produto
        this.em.remove(combos);
    }

    public void alterar (Combos combos) {
        em.merge(combos);
    }

}
