package dao;

import model.Combos;
import model.FormaPagamento;
import model.TipoAtividade;

import javax.persistence.EntityManager;
import java.util.List;

public class TipoAtividadeDao {
    private EntityManager em;

    public TipoAtividadeDao(EntityManager em) {
        this.em = em;
    }

    public void cadastrar(TipoAtividade tipoatividade) {
        this.em.persist(tipoatividade);
    }

    public List<TipoAtividade> consultaTipoAtiv() {
        String jpql = "SELECT c FROM TipoAtividade c";
        return em.createQuery(jpql, TipoAtividade.class).getResultList();
    }

    public Combos bucarPorId(int idTipoAtiv) {
        return em.find(Combos.class, idTipoAtiv);
    }

    public void remover (TipoAtividade tipoatividade) {
        // carrega no gerenciamento do JPA
        em.merge(tipoatividade);
        //remove produto
        this.em.remove(tipoatividade);
    }

    public void alterar (Combos combos) {
        em.merge(combos);
    }

}
