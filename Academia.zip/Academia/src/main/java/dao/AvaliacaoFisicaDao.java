package dao;

import model.Agenda;
import model.AvaliacaoFisica;

import javax.persistence.EntityManager;
import java.util.List;

public class AvaliacaoFisicaDao {
    private EntityManager em;

    public AvaliacaoFisicaDao(EntityManager em) {
        this.em = em;
    }

    public void cadastrar(AvaliacaoFisica avaliacaofisica) {
        this.em.persist(avaliacaofisica);
    }

    public List<AvaliacaoFisica> consulAvaliFisica() {
        String jpql = "SELECT c FROM AvaliacaoFisica c";
        return em.createQuery(jpql, AvaliacaoFisica.class).getResultList();
    }

    public AvaliacaoFisica bucarPorId(int idAvaliacaoFisica) {
        return em.find(AvaliacaoFisica.class, idAvaliacaoFisica);
    }

    public void remover (AvaliacaoFisica avaliacaofisica) {
        // carrega no gerenciamento do JPA
        em.merge(avaliacaofisica);
        //remove produto
        this.em.remove(avaliacaofisica);
    }

    public void alterar (AvaliacaoFisica avaliacaofisica) {
        em.merge(avaliacaofisica);
    }
}
