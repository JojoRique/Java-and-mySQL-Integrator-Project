package model;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

@Entity
@Table(name="matricula")
public class Matricula implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int idMatricula;
    private int idUsuario;
    private Date dataRenovacao;
    private int idAtividades;
    private int idFormPgto;

    public Matricula() {
    }

    public Matricula(int idUsuario, Date dataRenovacao, int idAtividades, int idFormPgto) {
        this.idUsuario = idUsuario;
        this.dataRenovacao = dataRenovacao;
        this.idAtividades = idAtividades;
        this.idFormPgto = idFormPgto;
    }


    public int getIdMatricula() {
        return idMatricula;
    }

    public void setIdMatricula(int idMatricula) {
        this.idMatricula = idMatricula;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Date getDataRenovacao() {
        return dataRenovacao;
    }

    public void setDataRenovacao(Date dataRenovacao) {this.dataRenovacao = dataRenovacao;
    }

    public int getIdAtividades() {
        return idAtividades;
    }

    public void setIdAtividades(int idAtividades) {
        this.idAtividades = idAtividades;
    }

    public int getIdFormPgto() {
        return idFormPgto;
    }

    public void setIdFormPgto(int idFormPgto) {
        this.idFormPgto = idFormPgto;
    }
}

