package model;

import javax.persistence.*;

@Entity
@Table(name="tipoatividades")
public class TipoAtividade {
    @Id
    @GeneratedValue(strategy =  GenerationType.IDENTITY)

    private int idAtividades;
    private String descricao;

    public TipoAtividade() {
    }

    public TipoAtividade(String descricao) {
        this.descricao = descricao;
    }

    public int getIdAtiv() {
        return idAtividades;
    }

    public void setIdAtiv(int idAtividades) {
        this.idAtividades= idAtividades;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
