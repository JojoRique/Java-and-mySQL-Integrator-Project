package model;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

@Entity
@Table(name="avaliacaofisica")
public class AvaliacaoFisica implements Serializable {
    @Id
    private int idUsuario;
    @Id
    private Date dataAvaliacao;
    float altura, peso, imc, percBracoDir, percBracoEsq, percCoxaDir, percCoxaEsq, panturrilhaDir, panturrilhaEsq,  percCostas, percAbdomen,  percPeitoral, circufAbdominal,  circufCoxaEsq,  circuCoxaDir;

    public AvaliacaoFisica() {
    }

    public AvaliacaoFisica(int idUsuario,Date dataAvaliacao, float altura, float peso, float imc, float percBracoDir, float percBracoEsq, float percCoxaDir, float percCoxaEsq, float panturrilhaDir, float panturrilhaEsq, float percCostas, float percAbdomen, float percPeitoral, float circufAbdominal, float circufCoxaEsq, float circuCoxaDir) {
        this.idUsuario = idUsuario;
        this.dataAvaliacao = dataAvaliacao;
        this.altura = altura;
        this.peso = peso;
        this.imc = imc;
        this.percBracoDir = percBracoDir;
        this.percBracoEsq = percBracoEsq;
        this.percCoxaDir = percCoxaDir;
        this.percCoxaEsq = percCoxaEsq;
        this.panturrilhaDir = panturrilhaDir;
        this.panturrilhaEsq = panturrilhaEsq;
        this.percCostas = percCostas;
        this.percAbdomen = percAbdomen;
        this.percPeitoral = percPeitoral;
        this.circufAbdominal = circufAbdominal;
        this.circufCoxaEsq = circufCoxaEsq;
        this.circuCoxaDir = circuCoxaDir;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Date getDataAvaliacao() {
        return dataAvaliacao;
    }

    public void setDataAvaliacao(Date dataAvaliacao) {
        this.dataAvaliacao = dataAvaliacao;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public float getImc() {
        return imc;
    }

    public void setImc(float imc) {
        this.imc = imc;
    }

    public float getPercBracoDir() {
        return percBracoDir;
    }

    public void setPercBracoDir(float percBracoDir) {
        this.percBracoDir = percBracoDir;
    }

    public float getPercBracoEsq() {
        return percBracoEsq;
    }

    public void setPercBracoEsq(float percBracoEsq) {
        this.percBracoEsq = percBracoEsq;
    }

    public float getPercCoxaDir() {
        return percCoxaDir;
    }

    public void setPercCoxaDir(float percCoxaDir) {
        this.percCoxaDir = percCoxaDir;
    }

    public float getPercCoxaEsq() {
        return percCoxaEsq;
    }

    public void setPercCoxaEsq(float percCoxaEsq) {
        this.percCoxaEsq = percCoxaEsq;
    }

    public float getPanturrilhaDir() {
        return panturrilhaDir;
    }

    public void setPanturrilhaDir(float panturrilhaDir) {
        this.panturrilhaDir = panturrilhaDir;
    }

    public float getPanturrilhaEsq() {
        return panturrilhaEsq;
    }

    public void setPanturrilhaEsq(float panturrilhaEsq) {
        this.panturrilhaEsq = panturrilhaEsq;
    }

    public float getPercCostas() {
        return percCostas;
    }

    public void setPercCostas(float percCostas) {
        this.percCostas = percCostas;
    }

    public float getPercAbdomen() {
        return percAbdomen;
    }

    public void setPercAbdomen(float percAbdomen) {
        this.percAbdomen = percAbdomen;
    }

    public float getPercPeitoral() {
        return percPeitoral;
    }

    public void setPercPeitoral(float percPeitoral) {
        this.percPeitoral = percPeitoral;
    }

    public float getCircufAbdominal() {
        return circufAbdominal;
    }

    public void setCircufAbdominal(float circufAbdominal) {
        this.circufAbdominal = circufAbdominal;
    }

    public float getCircufCoxaEsq() {
        return circufCoxaEsq;
    }

    public void setCircufCoxaEsq(float circufCoxaEsq) {
        this.circufCoxaEsq = circufCoxaEsq;
    }

    public float getCircuCoxaDir() {
        return circuCoxaDir;
    }

    public void setCircuCoxaDir(float circuCoxaDir) {
        this.circuCoxaDir = circuCoxaDir;
    }
}
