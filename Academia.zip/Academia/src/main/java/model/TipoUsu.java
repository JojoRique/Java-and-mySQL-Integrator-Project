package model;

import javax.persistence.*;

@Entity
@Table(name="tipousuario")
public class TipoUsu {
    @Id
    @GeneratedValue(strategy =  GenerationType.IDENTITY)

    private int idTipoUsu;
    private String descricao;

    public TipoUsu() {
    }

    public TipoUsu(String descricao) {
        this.descricao = descricao;
    }

    public int getIdTipoUsu() {
        return idTipoUsu;
    }

    public void setIdTipoUsu(int idTipoUsu) {
        this.idTipoUsu = idTipoUsu;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
