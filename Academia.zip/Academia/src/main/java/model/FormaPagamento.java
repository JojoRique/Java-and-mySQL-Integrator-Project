package model;

import javax.persistence.*;

@Entity
@Table(name="formapagamento")
public class FormaPagamento {
    @Id
    @GeneratedValue(strategy =  GenerationType.IDENTITY)

    private int idFormaPgto;
    private String descricao;

    public FormaPagamento() {
    }

    public FormaPagamento(String descricao) {
        this.descricao = descricao;
    }

    public int getId() {
        return idFormaPgto;
    }

    public void setId(int idFormaPgto) {
        this.idFormaPgto = idFormaPgto;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
