package model;


import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name="combos")
public class Combos implements Serializable {
    @Id
    @GeneratedValue(strategy =  GenerationType.IDENTITY)
    private int idCombo;
    private String descricao;
    private double valor;

    public Combos() {
    }

    public Combos(String descricao, double valor) {
        this.descricao = descricao;
        this.valor = valor;
    }

    public int getIdCombo() {
        return idCombo;
    }

    public void setIdCombo(int idCombo) {
        this.idCombo = idCombo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
}
