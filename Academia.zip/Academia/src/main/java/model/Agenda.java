package model;


import javax.persistence.*;
import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

@Entity
@Table(name="agenda")
public class Agenda implements Serializable {
    @Id
    private Date dataInicio;
    @Id
    private String hrInicial;
    private String hrFinal;
    private int idAtividades;
    private int idUsuario;

    public Agenda() {
    }

    public Agenda(Date dataInicio, String hrInicial, String hrFinal, int idAtividades, int idUsuario) {
        this.dataInicio = dataInicio;
        this.hrInicial = hrInicial;
        this.hrFinal = hrFinal;
        this.idAtividades = idAtividades;
        this.idUsuario = idUsuario;
    }

    public Date getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(Date dataInicio) {
        this.dataInicio = dataInicio;
    }

    public String getHrInicial() {
        return hrInicial;
    }

    public void setHrInicial(String hrInicial) {
        this.hrInicial = hrInicial;
    }

    public String getHrFinal() {
        return hrFinal;
    }

    public void setHrFinal(String hrFinal) {
        this.hrFinal = hrFinal;
    }

    public int getIdAtividades() {
        return idAtividades;
    }

    public void setIdAtividades(int idAtividades) {
        this.idAtividades = idAtividades;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }
}
