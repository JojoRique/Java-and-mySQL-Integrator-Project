package view;

import dao.*;
import model.*;
import util.JPAUtil;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.swing.*;

public class JanelaPrincipal implements ActionListener {
    JMenuItem usuario, consulUsu, tipoUsu, consulTipoUsu, agenda, consulAgenda, avaliacaoFisi, consulAvaliFisica, tipoAtivi, consuTipoAtivi, formaPagamento, consulFormaPagamento, combo, consulCombo, matricula, consulMatricula;

    public JanelaPrincipal() {
        JFrame f = new JFrame("Javass");
        f.setTitle("Menu Example");
        f.setSize(300, 250);
        f.setLocationRelativeTo(null);
        // Cria uma barra de menu para o JFrame
        JMenuBar menuBar = new JMenuBar();

        // Adiciona a barra de menu ao  frame
        f.setJMenuBar(menuBar);

        // Define e adiciona dois menus drop down na barra de menus
        JMenu fileMenu = new JMenu("Cadastro");
        JMenu consMenu = new JMenu("Consulta");
        JMenu academiaMenu = new JMenu("Academia");
        JMenu sobreMenu = new JMenu("Sobre");
        JMenu sairMenu = new JMenu("Sair");
        menuBar.add(fileMenu);
        menuBar.add(consMenu);
        menuBar.add(academiaMenu);
        menuBar.add(sobreMenu);
        menuBar.add(sairMenu);

        // Cria e adiciona um item simples para o menu
        usuario = new JMenuItem("Usuário");
        consulUsu = new JMenuItem("Usuário");
        tipoUsu = new JMenuItem("Tipos de Usuário");
        consulTipoUsu = new JMenuItem("Tipos de Usuário");
        agenda = new JMenuItem("Agenda");
        consulAgenda = new JMenuItem("Consulta da Agenda");
        avaliacaoFisi = new JMenuItem("Avaliação Fisica");
        consulAvaliFisica = new JMenuItem("Consulta da Avaliação Fisica");
        tipoAtivi = new JMenuItem("Tipo de Atividades");
        consuTipoAtivi = new JMenuItem("Tipo de Atividades");
        formaPagamento = new JMenuItem("Forma de Pagamento");
        consulFormaPagamento = new JMenuItem("Forma de Pagamento");
        combo = new JMenuItem("Combo");
        consulCombo = new JMenuItem("Combo");
        matricula = new JMenuItem("Matricula");
        consulMatricula = new JMenuItem("Consulta das Matriculas");


        JMenuItem exitAction = new JMenuItem("Exit");
        // Cria e aiciona um CheckButton como um item de menu
        //JCheckBoxMenuItem checkAction = new JCheckBoxMenuItem("Logged");


        fileMenu.add(usuario);
        fileMenu.add(tipoUsu);
        fileMenu.add(formaPagamento);
        fileMenu.add(combo);
        fileMenu.add(tipoAtivi);

        //fileMenu.addSeparator();
        fileMenu.add(exitAction);
        consMenu.add(consulUsu);
        consMenu.add(consulTipoUsu);
        consMenu.add(consulFormaPagamento);
        consMenu.add(consulCombo);
        consMenu.add(consuTipoAtivi);


        academiaMenu.add(agenda);
        academiaMenu.add(consulAgenda);
        academiaMenu.add(matricula);
        consMenu.add(consulMatricula);
        academiaMenu.add(avaliacaoFisi);
        academiaMenu.add(consulAvaliFisica);


        tipoUsu.addActionListener(this);
        consulTipoUsu.addActionListener(this);
        combo.addActionListener(this);
        consulCombo.addActionListener(this);
        formaPagamento.addActionListener(this);
        consulFormaPagamento.addActionListener(this);
        tipoAtivi.addActionListener(this);
        consuTipoAtivi.addActionListener(this);
        usuario.addActionListener(this);
        consulUsu.addActionListener(this);
        agenda.addActionListener(this);
        consulAgenda.addActionListener(this);
        matricula.addActionListener(this);
        consulMatricula.addActionListener(this);
        avaliacaoFisi.addActionListener(this);
        consulAvaliFisica.addActionListener(this);


        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String resultado = "";
        if (e.getSource() == tipoUsu) {
            String descricao = JOptionPane.showInputDialog("Digite seu nome");

            cadastrarTipoUsu(descricao);
            JOptionPane.showMessageDialog(null, "Cadastro com sucesso!");

        } else if (e.getSource() == consulTipoUsu) {
            resultado = consutaTipoUsu();
            JOptionPane.showMessageDialog(null, resultado);
        } else if (e.getSource() == combo) {
            String descricao = JOptionPane.showInputDialog("Insira as atividades do combo");
            double valor = Double.parseDouble(JOptionPane.showInputDialog("Insira o valor"));

            cadastrarCombo(descricao, valor);
            JOptionPane.showMessageDialog(null, "Cadastro com sucesso");

        } else if (e.getSource() == consulCombo) {
            resultado = consultaCombo();
            JOptionPane.showMessageDialog(null, resultado);
        }
        if (e.getSource() == formaPagamento) {
            String descricao = JOptionPane.showInputDialog("Digite a forma de pagamento");

            cadastrarFormaPgto(descricao);
            JOptionPane.showMessageDialog(null, "Cadastro com sucesso!");

        } else if (e.getSource() == consulFormaPagamento) {
            resultado = consultaFormaPgto();
            JOptionPane.showMessageDialog(null, resultado);

        }
        if (e.getSource() == tipoAtivi) {
            String descricao = JOptionPane.showInputDialog("Digite as atividades");

            cadastrarTipoAtiv(descricao);
            JOptionPane.showMessageDialog(null, "Cadastro com sucesso!");

        } else if (e.getSource() == consuTipoAtivi) {
            resultado = consulTipoAtiv();
            JOptionPane.showMessageDialog(null, resultado);

        } else if (e.getSource() == usuario) {
            int tipoUsu = 0;
            String nome = JOptionPane.showInputDialog("Digite o seu nome");
            String genero = JOptionPane.showInputDialog("Digite o seu genêro");
            long cpf = Long.parseLong(JOptionPane.showInputDialog("Insira seu CPF"));
            String email = JOptionPane.showInputDialog("Digite o seu email");
            String endereco = JOptionPane.showInputDialog("Digite o seu endereço");
            do {
                tipoUsu = Integer.parseInt(JOptionPane.showInputDialog("Digite 1-Instrutor ou 2-aluno"));
            } while (tipoUsu != 1 && tipoUsu != 2);

            cadastroUsu(nome, genero, cpf, email, endereco, tipoUsu);
            JOptionPane.showMessageDialog(null, "Cadastro com sucesso!");
        } else if (e.getSource() == consulUsu) {
            resultado = consulUsuario();
            JOptionPane.showMessageDialog(null, resultado);

        } else if (e.getSource() == agenda) {
            String dataInicio = JOptionPane.showInputDialog("Digite a data de incio");
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date dataI = null;
            try {
                dataI = dateFormat.parse(dataInicio);
                //  horaI = horaFormat.parse(dataInicio);
            } catch (ParseException ex) {
                throw new RuntimeException(ex);
            }
            String hrInicial = JOptionPane.showInputDialog("Digite o horario que irão começar as aulas");
            String hrFinal = JOptionPane.showInputDialog("Digite o horario que a aula irá finalizar");
            int idAtividades = Integer.parseInt(JOptionPane.showInputDialog("Digite o Id das atividades"));
            int idUsuario = Integer.parseInt(JOptionPane.showInputDialog("Digite os numeros de id dos usuarios"));

            cadastroAgenda(dataI, hrInicial, hrFinal, idAtividades, idUsuario);
            JOptionPane.showMessageDialog(null, "Cadastro com sucesso!");
        } else if (e.getSource() == consulAgenda) {
            resultado = consultaAgenda();
            JOptionPane.showMessageDialog(null, resultado);
        } else if (e.getSource() == matricula) {
            int idUsuario = Integer.parseInt(JOptionPane.showInputDialog("Digite o id do usuario"));
            String dataRenovacao = JOptionPane.showInputDialog("Digite a data de renovação");
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date dataR = null;
            try {
                dataR = dateFormat.parse(dataRenovacao);
            } catch (ParseException ex) {
                throw new RuntimeException(ex);
            }
            int idAtividades = Integer.parseInt(JOptionPane.showInputDialog("Digite o id das atividades"));
            int idFormPgto = Integer.parseInt(JOptionPane.showInputDialog("Digite o id do pagamento"));
            cadastroMatricula(idUsuario, dataR, idAtividades, idFormPgto);
            JOptionPane.showMessageDialog(null, "Cadastro com sucesso!");


        } else if (e.getSource() == consulMatricula) {
            resultado = consultaMatricula();
            JOptionPane.showMessageDialog(null, resultado);
        } else if (e.getSource() == avaliacaoFisi) {
            int idusuario = Integer.parseInt(JOptionPane.showInputDialog("Digite o id do usuario"));
            String dataAvaliacao = JOptionPane.showInputDialog("Digite a data da renovação");
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date dataAva = null;
            try {
                dataAva = dateFormat.parse(dataAvaliacao);
            } catch (ParseException ex) {
                throw new RuntimeException(ex);
            }
            float altura = Float.parseFloat(JOptionPane.showInputDialog("Digite sua altura"));
            float peso = Float.parseFloat(JOptionPane.showInputDialog("Digite seu peso"));
            float imc = peso / (altura * altura);
            JOptionPane.showMessageDialog(null, "Seu imc é " + imc);
            float percBracoDir = Float.parseFloat(JOptionPane.showInputDialog("Digite a porcentagem do seu braço direito"));
            float percBracoEsq = Float.parseFloat(JOptionPane.showInputDialog("Digite a porcentagem do seu braço esquerdo"));
            float percCoxaDir = Float.parseFloat(JOptionPane.showInputDialog("Digite a porcentagem da sua coxa direita"));
            float percCoxaEsq = Float.parseFloat(JOptionPane.showInputDialog("Digite a porcentagem da sua coxa Esquerda"));
            float panturrilhaDir = Float.parseFloat(JOptionPane.showInputDialog("Digite a porcentagem da sua panturrilha direita"));
            float panturrilhaEsq = Float.parseFloat(JOptionPane.showInputDialog("Digite a porcentagem da sua panturrilha esquerda"));
            float percCostas = Float.parseFloat(JOptionPane.showInputDialog("Digite a porcentagem da sua costas"));
            float percAbdomen = Float.parseFloat(JOptionPane.showInputDialog("Digite a porcentagem do seu abdomen"));
            float percPeitoral = Float.parseFloat(JOptionPane.showInputDialog("Digite a porcentagem de seu peitoral"));
            float circufAbdominal = Float.parseFloat(JOptionPane.showInputDialog("Digite sua circuferência abdominal"));
            float circufCoxaEsq = Float.parseFloat(JOptionPane.showInputDialog("Digite a circufência da sua coxa esquerda"));
            float circuCoxaDir = Float.parseFloat(JOptionPane.showInputDialog("Digite a circufência da sua coxa direita"));

            cadastroAvaliacaoFis(idusuario, dataAva, altura, peso, imc, percBracoDir, percBracoEsq, percCoxaDir, percCoxaEsq, panturrilhaDir, panturrilhaEsq, percCostas, percAbdomen, percPeitoral, circufAbdominal, circufCoxaEsq, circuCoxaDir);
            JOptionPane.showMessageDialog(null, "Cadastro com sucesso!");

        } else if (e.getSource() == consulAvaliFisica) {
            resultado = consultaAvaliacaoFisi();
            JOptionPane.showMessageDialog(null, resultado);
        }

    }

    public static void cadastrarTipoUsu(String descricao) {
        TipoUsu tipoUsu = new TipoUsu(descricao);

        // fazendo a conexão com o banco
        EntityManager em = JPAUtil.getEntityManager();
        TipoUsuDao dao = new TipoUsuDao(em);

        //inicializa a transação
        em.getTransaction().begin();
        // chama o método para cadastrar no banco

        dao.cadastrar(tipoUsu);

        //valida a transação
        em.getTransaction().commit();
        // fecha conexão com o banco
        em.close();
    }

    private static String consutaTipoUsu() {
        // fazendo a conexão com o banco
        EntityManager em = JPAUtil.getEntityManager();
        TipoUsuDao dao = new TipoUsuDao(em);

        List<TipoUsu> todos = dao.consultaTodos();
        int tam = todos.size();
        String resultado = "";
        // concatenar todos os registros na variável resultado
        for (int i = 0; i < tam; i++) {
            resultado += todos.get(i).getIdTipoUsu() + " - " + todos.get(i).getDescricao() + " - " + "\n";

        }
        return resultado;

    }


    public static void cadastrarCombo(String descricao, double valor) {
        Combos combos = new Combos(descricao, valor);

        // fazendo a conexão com o banco
        EntityManager em = JPAUtil.getEntityManager();
        CombosDao dao = new CombosDao(em);

        //inicializa a transação
        em.getTransaction().begin();
        // chama o método para cadastrar no banco

        dao.cadastrar(combos);

        //valida a transação
        em.getTransaction().commit();
        // fecha conexão com o banco
        em.close();
    }

    private static String consultaCombo() {
        // fazendo a conexão com o banco
        EntityManager em = JPAUtil.getEntityManager();
        CombosDao dao = new CombosDao(em);

        List<Combos> todos = dao.consultaCombo();
        int tam = todos.size();
        String resultado = "";
        // concatenar todos os registros na variável resultado
        for (int i = 0; i < tam; i++) {
            resultado += todos.get(i).getIdCombo() + " - " + todos.get(i).getDescricao() + " - " + todos.get(i).getValor() + "\n";

        }
        return resultado;
    }

    public static void cadastrarFormaPgto(String descricao) {
        FormaPagamento formaPagamento = new FormaPagamento(descricao);

        // fazendo a conexão com o banco
        EntityManager em = JPAUtil.getEntityManager();
        FormaPagamentoDao dao = new FormaPagamentoDao(em);

        //inicializa a transação
        em.getTransaction().begin();
        // chama o método para cadastrar no banco

        dao.cadastrar(formaPagamento);

        //valida a transação
        em.getTransaction().commit();
        // fecha conexão com o banco
        em.close();
    }

    private static String consultaFormaPgto() {
        // fazendo a conexão com o banco
        EntityManager em = JPAUtil.getEntityManager();
        FormaPagamentoDao dao = new FormaPagamentoDao(em);

        List<FormaPagamento> todos = dao.consultaFormaPgto();
        int tam = todos.size();
        String resultado = "";
        // concatenar todos os registros na variável resultado
        for (int i = 0; i < tam; i++) {
            resultado += todos.get(i).getId() + " - " + todos.get(i).getDescricao() + " - " + "\n";

        }
        return resultado;

    }

    public static void cadastrarTipoAtiv(String descricao) {
        TipoAtividade tipoatividade = new TipoAtividade(descricao);

        // fazendo a conexão com o banco
        EntityManager em = JPAUtil.getEntityManager();
        TipoAtividadeDao dao = new TipoAtividadeDao(em);

        //inicializa a transação
        em.getTransaction().begin();
        // chama o método para cadastrar no banco

        dao.cadastrar(tipoatividade);

        //valida a transação
        em.getTransaction().commit();
        // fecha conexão com o banco
        em.close();
    }

    private static String consulTipoAtiv() {
        // fazendo a conexão com o banco
        EntityManager em = JPAUtil.getEntityManager();
        TipoAtividadeDao dao = new TipoAtividadeDao(em);

        List<TipoAtividade> todos = dao.consultaTipoAtiv();
        int tam = todos.size();
        String resultado = "";
        // concatenar todos os registros na variável resultado
        for (int i = 0; i < tam; i++) {
            resultado += todos.get(i).getIdAtiv() + " - " + todos.get(i).getDescricao() + " - " + "\n";

        }
        return resultado;

    }

    public static void cadastroUsu(String nome, String genero, long cpf, String email, String endereco, int tipoUsu) {

        Usuario usuario = new Usuario(nome, genero, cpf, email, endereco, tipoUsu);

        // fazendo a conexão com o banco
        EntityManager em = JPAUtil.getEntityManager();
        UsuarioDao dao = new UsuarioDao(em);

        //inicializa a transação
        em.getTransaction().begin();
        // chama o método para cadastrar no banco

        dao.cadastrar(usuario);

        //valida a transação
        em.getTransaction().commit();
        // fecha conexão com o banco
        em.close();
    }

    private static String consulUsuario() {
        // fazendo a conexão com o banco
        EntityManager em = JPAUtil.getEntityManager();
        UsuarioDao dao = new UsuarioDao(em);

        List<Usuario> todos = dao.consultaUsu();
        int tam = todos.size();
        String resultado = "";
        // concatenar todos os registros na variável resultado
        for (int i = 0; i < tam; i++) {
            resultado += todos.get(i).getIdUsuario() + " - " + todos.get(i).getSexo() + " - " + todos.get(i).getCpf() + " - " + todos.get(i).getEmail() + " - " + todos.get(i).getEndereco() + " - " + todos.get(i).getIdTipoUsu() + " - " + "\n";


        }
        return resultado;

    }

    public static void cadastroAgenda(Date dataInicio, String hrInicial, String hrFinal, int idAtividades,
                                      int idUsuario) {
        Agenda agenda = new Agenda(dataInicio, hrInicial, hrFinal, idAtividades, idUsuario);

        // fazendo a conexão com o banco
        EntityManager em = JPAUtil.getEntityManager();
        AgendaDao dao = new AgendaDao(em);

        //inicializa a transação
        em.getTransaction().begin();
        // chama o método para cadastrar no banco

        dao.cadastrar(agenda);

        //valida a transação
        em.getTransaction().commit();
        // fecha conexão com o banco
        em.close();
    }

    private static String consultaAgenda() {
        // fazendo a conexão com o banco
        EntityManager em = JPAUtil.getEntityManager();
        AgendaDao dao = new AgendaDao(em);

        List<Agenda> todos = dao.consulAgenda();
        int tam = todos.size();
        String resultado = "";
        // concatenar todos os registros na variável resultado
        for (int i = 0; i < tam; i++) {
            resultado += todos.get(i).getDataInicio() + " - " + todos.get(i).getHrInicial() + " - " + todos.get(i).getHrFinal() + " - " + todos.get(i).getIdUsuario() + " - " + todos.get(i).getIdAtividades() + " - " + "\n";

        }
        return resultado;
    }

    public static void cadastroMatricula(int idUsuario, Date dataRenovacao, int idAtividades, int idFormPgto) {
        Matricula matricula = new Matricula(idUsuario, dataRenovacao, idAtividades, idFormPgto);

        // fazendo a conexão com o banco
        EntityManager em = JPAUtil.getEntityManager();
        MatriculaDao dao = new MatriculaDao(em);

        //inicializa a transação
        em.getTransaction().begin();
        // chama o método para cadastrar no banco

        dao.cadastrar(matricula);

        //valida a transação
        em.getTransaction().commit();
        // fecha conexão com o banco
        em.close();
    }

    private static String consultaMatricula() {
        // fazendo a conexão com o banco
        EntityManager em = JPAUtil.getEntityManager();
        MatriculaDao dao = new MatriculaDao(em);

        List<Matricula> todos = dao.consulMatricula();
        int tam = todos.size();
        String resultado = "";
        // concatenar todos os registros na variável resultado
        for (int i = 0; i < tam; i++) {
            resultado += todos.get(i).getIdMatricula() + " - " + todos.get(i).getIdUsuario() + " - " + todos.get(i).getDataRenovacao() + " - " + todos.get(i).getIdAtividades() + " - " + todos.get(i).getIdFormPgto() + " - " + "\n";


        }
        return resultado;
    }

    public static void cadastroAvaliacaoFis(int idusuario, Date dataAva, float altura, float peso, float imc, float percBracoDir, float percBracoEsq, float percCoxaDir, float percCoxaEsq, float panturrilhaDir, float panturrilhaEsq, float percCostas, float percAbdomen, float percPeitoral, float circufAbdominal, float circufCoxaEsq, float circuCoxaDir) {
        AvaliacaoFisica avaliacaofisica = new AvaliacaoFisica(idusuario, dataAva, altura, peso, imc, percBracoDir, percBracoEsq, percCoxaDir, percCoxaEsq, panturrilhaDir, panturrilhaEsq, percCostas, percAbdomen, percPeitoral, circufAbdominal, circufCoxaEsq, circuCoxaDir);

        // fazendo a conexão com o banco
        EntityManager em = JPAUtil.getEntityManager();
        AvaliacaoFisicaDao dao = new AvaliacaoFisicaDao(em);

        //inicializa a transação
        em.getTransaction().begin();
        // chama o método para cadastrar no banco

        dao.cadastrar(avaliacaofisica);

        //valida a transação
        em.getTransaction().commit();
        // fecha conexão com o banco
        em.close();
    }

    private static String consultaAvaliacaoFisi() {
        // fazendo a conexão com o banco
        EntityManager em = JPAUtil.getEntityManager();
        AvaliacaoFisicaDao dao = new AvaliacaoFisicaDao(em);

        List<AvaliacaoFisica> todos = dao.consulAvaliFisica();
        int tam = todos.size();
        String resultado = "";
        // concatenar todos os registros na variável resultado
        for (int i = 0; i < tam; i++) {
            resultado += todos.get(i).getIdUsuario() + " - " + todos.get(i).getDataAvaliacao() + " - " + todos.get(i).getAltura() + " - " + todos.get(i).getPeso() + " - " + todos.get(i).getImc() + " - " + todos.get(i).getPercBracoDir() + " - "
                    + todos.get(i).getPercBracoEsq() + " - " + todos.get(i).getPercCoxaDir() + " - " + todos.get(i).getPercCoxaEsq() + " - " + todos.get(i).getPanturrilhaDir() + " - "+ todos.get(i).getPanturrilhaEsq() + " - "
                    + todos.get(i).getPercCostas() + " - " + todos.get(i).getPercAbdomen() + " - " + todos.get(i).getPercPeitoral() + " - " + todos.get(i).getCircufAbdominal() + " - " + todos.get(i).getCircufCoxaEsq() + " - " + todos.get(i).getCircuCoxaDir() + " - " + "\n";}
        return resultado;

    }
}

