package view;

import javax.swing.*;

public class SistemaAcademia {
    public static void main(String[] args) {
        JanelaPrincipal jp = new JanelaPrincipal();


    }
}